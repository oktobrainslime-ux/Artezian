# Весёлый Капитал — проект для AndroidIDE

Это нативный Android/Gradle-проект без Expo и React Native. Он предназначен для сборки APK непосредственно на Android-телефоне через AndroidIDE.

## Сборка
1. Распакуйте ZIP.
2. В AndroidIDE выберите **Open project** и откройте корневую папку проекта (где лежат `settings.gradle` и `build.gradle`).
3. Дождитесь Gradle Sync.
4. Выберите **Build → Assemble Debug** (или соответствующую команду сборки APK).
5. APK будет в `app/build/outputs/apk/debug/app-debug.apk`.
6. Переименуйте его в `vesely-capital.apk` при необходимости.

Название приложения: Весёлый Капитал
Package: ru.veselyvodovoz.capital
Версия: 1.0.0
